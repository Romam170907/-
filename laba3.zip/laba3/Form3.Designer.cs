﻿namespace laba3
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonSave = new Button();
            textBoxName = new TextBox();
            textBoxDirector = new TextBox();
            textBoxYear = new TextBox();
            textBoxGenre = new TextBox();
            textBoxRating = new TextBox();
            buttonClear = new Button();
            SuspendLayout();
            // 
            // buttonSave
            // 
            buttonSave.Location = new Point(347, 259);
            buttonSave.Name = "buttonSave";
            buttonSave.Size = new Size(75, 23);
            buttonSave.TabIndex = 0;
            buttonSave.Text = "button1";
            buttonSave.UseVisualStyleBackColor = true;
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(58, 138);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(100, 23);
            textBoxName.TabIndex = 1;
            // 
            // textBoxDirector
            // 
            textBoxDirector.Location = new Point(192, 138);
            textBoxDirector.Name = "textBoxDirector";
            textBoxDirector.Size = new Size(100, 23);
            textBoxDirector.TabIndex = 2;
            // 
            // textBoxYear
            // 
            textBoxYear.Location = new Point(312, 138);
            textBoxYear.Name = "textBoxYear";
            textBoxYear.Size = new Size(100, 23);
            textBoxYear.TabIndex = 3;
            // 
            // textBoxGenre
            // 
            textBoxGenre.Location = new Point(445, 138);
            textBoxGenre.Name = "textBoxGenre";
            textBoxGenre.Size = new Size(100, 23);
            textBoxGenre.TabIndex = 4;
            // 
            // textBoxRating
            // 
            textBoxRating.Location = new Point(584, 138);
            textBoxRating.Name = "textBoxRating";
            textBoxRating.Size = new Size(100, 23);
            textBoxRating.TabIndex = 5;
            // 
            // buttonClear
            // 
            buttonClear.Location = new Point(467, 268);
            buttonClear.Name = "buttonClear";
            buttonClear.Size = new Size(75, 23);
            buttonClear.TabIndex = 6;
            buttonClear.Text = "button1";
            buttonClear.UseVisualStyleBackColor = true;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonClear);
            Controls.Add(textBoxRating);
            Controls.Add(textBoxGenre);
            Controls.Add(textBoxYear);
            Controls.Add(textBoxDirector);
            Controls.Add(textBoxName);
            Controls.Add(buttonSave);
            Name = "Form3";
            Text = "Form3";
            Load += Form3_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonSave;
        private TextBox textBoxName;
        private TextBox textBoxDirector;
        private TextBox textBoxYear;
        private TextBox textBoxGenre;
        private TextBox textBoxRating;
        private Button buttonClear;
    }
}