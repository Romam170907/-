﻿namespace laba3
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBoxName = new TextBox();
            textBoxDirector = new TextBox();
            textBoxYear = new TextBox();
            textBoxGenre = new TextBox();
            textBoxRating = new TextBox();
            buttonSave = new Button();
            SuspendLayout();
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(46, 124);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(100, 23);
            textBoxName.TabIndex = 0;
            // 
            // textBoxDirector
            // 
            textBoxDirector.Location = new Point(192, 124);
            textBoxDirector.Name = "textBoxDirector";
            textBoxDirector.Size = new Size(100, 23);
            textBoxDirector.TabIndex = 1;
            // 
            // textBoxYear
            // 
            textBoxYear.Location = new Point(346, 124);
            textBoxYear.Name = "textBoxYear";
            textBoxYear.Size = new Size(100, 23);
            textBoxYear.TabIndex = 2;
            // 
            // textBoxGenre
            // 
            textBoxGenre.Location = new Point(514, 124);
            textBoxGenre.Name = "textBoxGenre";
            textBoxGenre.Size = new Size(100, 23);
            textBoxGenre.TabIndex = 3;
            // 
            // textBoxRating
            // 
            textBoxRating.Location = new Point(658, 124);
            textBoxRating.Name = "textBoxRating";
            textBoxRating.Size = new Size(100, 23);
            textBoxRating.TabIndex = 4;
            // 
            // buttonSave
            // 
            buttonSave.Location = new Point(355, 283);
            buttonSave.Name = "buttonSave";
            buttonSave.Size = new Size(75, 23);
            buttonSave.TabIndex = 5;
            buttonSave.Text = "button1";
            buttonSave.UseVisualStyleBackColor = true;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonSave);
            Controls.Add(textBoxRating);
            Controls.Add(textBoxGenre);
            Controls.Add(textBoxYear);
            Controls.Add(textBoxDirector);
            Controls.Add(textBoxName);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxName;
        private TextBox textBoxDirector;
        private TextBox textBoxYear;
        private TextBox textBoxGenre;
        private TextBox textBoxRating;
        private Button buttonSave;
    }
}