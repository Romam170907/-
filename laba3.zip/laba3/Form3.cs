﻿using System;
using System.IO;
using System.Windows.Forms;

namespace laba3
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();

            // Если кнопки не подписаны автоматически, подпишем их вручную
            this.buttonSave.Click += new EventHandler(buttonSave_Click);
            this.buttonClear.Click += new EventHandler(buttonClear_Click);
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
        private void buttonSave_Click(object sender, EventArgs e)
        {
            // Проверка на пустые поля
            if (string.IsNullOrWhiteSpace(textBoxName.Text) ||
                string.IsNullOrWhiteSpace(textBoxDirector.Text) ||
                string.IsNullOrWhiteSpace(textBoxYear.Text) ||
                string.IsNullOrWhiteSpace(textBoxGenre.Text) ||
                string.IsNullOrWhiteSpace(textBoxRating.Text))
            {
                MessageBox.Show("Заполните все поля!", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Проверка года
            if (!int.TryParse(textBoxYear.Text, out int year))
            {
                MessageBox.Show("Год должен быть числом!", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Проверка рейтинга
            if (!int.TryParse(textBoxRating.Text, out int rating))
            {
                MessageBox.Show("Рейтинг должен быть числом!", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Путь к файлу
            string filePath = "kino.csv";

            try
            {
                // Формируем строку
                string newRecord = $"{textBoxName.Text} {textBoxDirector.Text} {year} {textBoxGenre.Text} {rating}";

                // Записываем в файл
                using (StreamWriter sw = new StreamWriter(filePath, true))
                {
                    sw.WriteLine(newRecord);
                }

                MessageBox.Show($"Запись добавлена в {filePath}!\n\n{newRecord}", "Успех",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Очищаем поля
                textBoxName.Text = "";
                textBoxDirector.Text = "";
                textBoxYear.Text = "";
                textBoxGenre.Text = "";
                textBoxRating.Text = "";

                // Закрываем форму
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxName.Text = "";
            textBoxDirector.Text = "";
            textBoxYear.Text = "";
            textBoxGenre.Text = "";
            textBoxRating.Text = "";
        }
    }
}