﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace laba3
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
        private void buttonSave_Click(object sender, EventArgs e)
        {
            // Проверяем, что все поля заполнены
            if (string.IsNullOrWhiteSpace(textBoxName.Text) ||
                string.IsNullOrWhiteSpace(textBoxDirector.Text) ||
                string.IsNullOrWhiteSpace(textBoxYear.Text) ||
                string.IsNullOrWhiteSpace(textBoxGenre.Text) ||
                string.IsNullOrWhiteSpace(textBoxRating.Text))
            {
                MessageBox.Show("Заполните все поля!", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Проверяем, что год и рейтинг - числа
            if (!int.TryParse(textBoxYear.Text, out int year))
            {
                MessageBox.Show("Год должен быть числом!", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(textBoxRating.Text, out int rating))
            {
                MessageBox.Show("Рейтинг должен быть числом!", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Формируем строку для записи
            string newRecord = $"{textBoxName.Text} {textBoxDirector.Text} {year} {textBoxGenre.Text} {rating}";

            // Путь к файлу (можно выбрать или использовать фиксированный)
            string filePath = "movies.csv";

            try
            {
                // Добавляем запись в файл
                using (StreamWriter sw = new StreamWriter(filePath, true))
                {
                    sw.WriteLine(newRecord);
                }

                MessageBox.Show("Запись успешно добавлена!", "Успех",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);


                // Закрываем форму
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при сохранении: " + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
